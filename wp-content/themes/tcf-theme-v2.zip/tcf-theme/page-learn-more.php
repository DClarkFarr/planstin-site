<?php
/*
 Template Name: Learn more page
*/
?>


<section class="section-sm bg-gray-light">
    <div class="container text-center">
        <h2 class="m-0 text-secondary f-24 text-uppercase">Grow your business with Planstin</h2>
    </div>
</section>

<section class="section benefits learn-more bg-light-alt">
    <div class="container">
      
      <div class="row">
          <div class="col-md-7">
              <p>We offer business solutions for small or big groups, because  Business is our passion, we know how to help and we deliver.</p>
              
              <h3 class="h3-head-blck">Health Benefits</h3>
              <p class="mgrb">We have top of class business health plans available for small businesses. Our plans are unique and can save you a ton of money both on the monthly budget and when you need to get care.</p>
              
              <div class="row">
                  <div class="col-md-6">
                      <h5 class="text-darkest font-blod">Base Health</h5>
                      <p>Get the coverage that you need with access to doctors, prescriptions and other medical care.</p>
                  </div>
                  <div class="col-md-6">
                      <h5 class="text-darkest font-blod">Catastrophic</h5>
                      <p>When the unexpected medical costs come, you can be ready with a plan that is right for you and your budget..</p>
                  </div>
                  <div class="col-md-6">
                      <h5 class="text-darkest font-blod">Dental</h5>
                      <p>The preventive health care of a dental plan can make all the difference now and years to come.</p>
                  </div>
                  <div class="col-md-6">
                      <h5 class="text-darkest font-blod">Vision</h5>
                      <p>Seeing clearly can make all the difference when driving, watching a movie, reading a book or just seeing life.</p>
                  </div>
                  
              </div>
              
               <h3 class="h3-head-blck mgrt1">Payroll & HR</h3>
               <p class="mbrb2">We make payroll easy and effective! We will process all your local and federal taxes and forms. We offer the best of online tools, direct deposit and much more.  </p>
              
              
          </div>
          <div class="col-md-5">
              <img class="img-fluid" src="<?php bloginfo('stylesheet_directory'); ?>/assets/images/meet.png" alt="">
          </div>
      </div>
      <div class="row mgrt-20">
          <div class="col-md-6">
              <h5 class="text-darkest font-blod">Full service Payroll</h5>
              <p>Payroll made easy with a dedicated payroll specialist, all taxes and forms processed, direct deposit payroll, HR Suite and more.  Our services can make payroll deductions and workers comp reporting a breeze so that you can focus on your business.</p>
          </div>
           <div class="col-md-6">
              <h5 class="text-darkest font-blod">Owner's Payroll</h5>
              <p>We have a payroll solution specifically designed for business owners and partners.  With the dedicated payroll specialist, we will process all taxes and forms, direct deposit payroll and more.</p>
          </div>
          <div class="col-md-6">
              <h5 class="text-darkest font-blod">Workers Compensation</h5>
              <p>We help companies with obtaining and maintaining workers compensation coverage with ease.  Our clients enjoy pay-as-you-go or payroll integrated billing for easy audits.</p>
          </div>
           <div class="col-md-6">
              <h5 class="text-darkest font-blod">HR Suite</h5>
              <p>Our HR Suite comes with our Full Service Payroll or you can subscribe your business.  The HR Suite is perfect for keep your business in HR compliance using tools, forms, trainings, employee handbooks and a compliance suite.</p>
          </div>
          
          <img class="img-fluid img-mddle thumbs-up-img" src="<?php bloginfo('stylesheet_directory'); ?>/assets/images/thumbs-up.png" alt="">
           
      </div>
      
      
      
      
    </div>
</section>

