<?php
/*
 Template Name: Vision Plan Page
*/
?>


<section class="section-sm bg-gray-light">
    <div class="container text-center">
        <h2 class="m-0 text-secondary f-24 text-uppercase">VISION PLAN</h2>
    </div>
</section>

<section class="section benefits learn-more bg-white">
    <div class="container">
     
     <p class="text-darkest">Seeing clearly can make all the difference when driving, watching a movie, reading a book or just seeing life. Enjoy what life has to show you and enjoy the savings that our vision coverage can bring you with Planstin. See below plan overview.
        </p>
  
    <div class="row base-health-two">
        <div class="col-md-6">
            <h4 class="head-h4 text-red">Vision Plan</h4>
            <div class="hsa-plan-no">
               
               <ul class="hsa-plans">
                  <li>
                    <h5 class="text-light head-medium mgrt-20">Network</h5>
                        <p class="text-light mgrb-5">We will work with any licensed provider. You can choose who you would like to work with! Reimbursements for providers that do not bill the plan also available.</p>
                       
                  </li>
                  <li>
                      <h5 class="text-light head-medium mgrt-20">Frame, Lenses and/or Contact Allowance</h5>
                        <p class="text-light mgrb-5">Plan will pay up to $150 annually for a combined total for frames, lenses and/or contacts.</p>
                  </li>
                  <li>
                      <h5 class="text-light head-medium mgrt-30">Copay List</h5>
                       
                        <ul class="hsa-plans1">
                            <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li143"><p class="text-light no-mgrb">Eye Health Exam</p></li>
                                   <li class="li2"><p class="text-light no-mgrb">$10</p></li>
                               </ul>
                            </li>
                            <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li143"><p class="text-light no-mgrb">Contact Evaluation</p></li>
                                   <li class="li3"><p class="text-light no-mgrb">$10 Additional</p></li>
                               </ul>
                            </li>
                            <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li143"><p class="text-light no-mgrb">Spectacle Lenses Evaluation</p></li>
                                   <li class="li3"><p class="text-light no-mgrb">$10 Additional</p></li>
                               </ul>
                            </li>
                            <li>
                                 <ul class="hsa-plans-cost">
                                   <li class="li143"><p class="text-light no-mgrb">Anti-Reflective Coating </p></li>
                                   <li class="li3"><p class="text-light no-mgrb">$35 Additional</p></li>
                               </ul>
                            </li>
                            <li>
                                 <ul class="hsa-plans-cost">
                                   <li class="li143"><p class="text-light no-mgrb">Progressive Lenses </p></li>
                                   <li class="li3"><p class="text-light no-mgrb">$10 Additional</p></li>
                               </ul>
                            </li>
                            
                        </ul>
                        <div class="clearfix"></div>
                        <p class="text-light mgrt-20">Plan will pay up to $150 annually for all vision services per member.</p>
                  </li>
                    <li>
                      <h5 class="text-light head-medium mgrt-30">Costco Reimbursement</h5>
                     <p class="text-light">If services are rendered at a Costco Vision Center, Costco Optical or Independent Doctor of Optometry located in or near most <a href="#" target="_blank">Costco locations</a>, plan will reimburse and waive all copays.</p>
                  </li>
                  <li>
                     <div class="clearfix"></div>
                      <h5 class="text-light head-medium mgrt-30 no-mgrb">Plan Outline</h5>
                     <a class="download-pln text-light" href="https://drive.google.com/open?id=1RYeRHL_6Kw39wv2VjW2RY6J3GPm-mAsA" target="_blank"><span class="link-name">Download Outline</span> <i class="far fa-fw mr-3 d-inline-block fa-download" aria-hidden="true"></i></a>
                  </li>
                  <li>
                     <div class="clearfix"></div>
                      <h5 class="text-light head-medium mgrt-30">Monthly Rates</h5>
                      <ul class="hsa-plans1">
                            <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li11"><p class="text-light no-mgrb">Employee Only </p></li>
                                   <li class="li2"><p class="text-light no-mgrb">$9</p></li>
                               </ul>
                            </li>
                            <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li11"><p class="text-light no-mgrb">Employee + Spouse</p></li>
                                   <li class="li2"><p class="text-light no-mgrb">$15</p></li>
                               </ul>
                            </li>
                            <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li11"><p class="text-light no-mgrb">Employee + Children</p></li>
                                   <li class="li2"><p class="text-light no-mgrb">$14</p></li>
                               </ul>
                            </li>
                            <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li11"><p class="text-light no-mgrb">Employee + Family</p></li>
                                   <li class="li2"><p class="text-light no-mgrb">$22</p></li>
                               </ul>
                            </li>
                            
                            
                        </ul>
                  </li>
               </ul>
            </div>
        </div>
        
        <div class="col-md-6">
            <img src="<?php bloginfo('stylesheet_directory'); ?>/assets/images/professional-man-in-glasses.png" alt="" class="img-fluid glasses-man">
        </div>
       
        
    </div>
      
      
      
      
    </div>
</section>

