<?php
/*
 Template Name: Owner's Payroll
*/
?>


<section class="section-sm bg-gray-light">
    <div class="container text-center">
        <h2 class="m-0 text-secondary f-24 text-uppercase">OWNER'S PAYROLL</h2>
    </div>
</section>

<section class="section benefits learn-more bg-white">
    <div class="container">
     
     <p class="text-darkest txt-center">Payroll made easy with a dedicated payroll specialist, all taxes and forms processed, direct deposit payroll, HR Suite and more.  Our services can make payroll deductions and workers comp reporting a breeze so that you can focus on your business.
        </p>
     
      
    <div class="row base-health-two">
       <div class="col-md-1"></div>
        <div class="col-md-4">
                <h4 class="head-h4 text-red">What's included?</h4>
                <div class="included">
                     <p class="text-light no-mgrb">

                       Local Payroll Forms and Taxes <br>
                        Federal Payroll Forms and Taxes	<br>
                        Annual W2's	<br>
                        Annual 1099's	<br>	
                        Employer Online Access		<br>
                        Benefit Integration	<br>	
                        Direct Deposit	<br>
                        Dedicated Payroll Specialist	

                     </p>
                     <h5 class="head-medium text-light mgrt-50">Base Plan</h5>
                     <p class="text-light">$50.00 Monthly</p>
                     <h5 class="head-medium text-light mgrt-20">Per Employee/Contractor</h5>
                     <p class="text-light">$2.00 monthly</p>
                    
                </div>
            </div>
            <div class="col-md-7">
                <img  class="img-fluid img-middle" src="<?php bloginfo('stylesheet_directory'); ?>/assets/images/men.png" alt="">
            </div>
        </div>
        
        
        
        
    </div>
      
  
</section>

