<?php
/*
 Template Name: HR Suite
*/
?>


<section class="section-sm bg-gray-light">
    <div class="container text-center">
        <h2 class="m-0 text-secondary f-24 text-uppercase">HR SUITE</h2>
    </div>
</section>

<section class="section benefits learn-more bg-white">
    <div class="container">
     
     <p class="text-darkest txt-center">Payroll made easy with a dedicated payroll specialist, all taxes and forms processed, direct deposit payroll, HR Suite and more.  Our services can make payroll deductions and workers comp reporting a breeze so that you can focus on your business.
        </p>
     
      
    <div class="row base-health-two">
        <div class="col-md-4">
                <h4 class="head-h4 text-red">What's included?</h4>
                <div class="included">
                     <h5 class="head-medium text-light">ThinkHR Suite</h5>
                     <p class="text-light no-mgrb">
                        Live Unlimited HR Access <br>	
                        Employee Video Training	<br>
                        Employee Handbook<br>	
                        HR Documents, Tools, Templates	<br>
                        Benefits Compliance Suite	

                     </p>
                     <h5 class="head-medium text-light mgrt-50">Base Plan</h5>
                     <p class="text-light">$50.00 Monthly</p>
                    
                </div>
        </div>
          <div class="col-md-2"></div>
           <div class="col-md-4">
                <h4 class="head-h4 text-red">What's ThinkHR Suite?</h4>
                <div class="included">
                     <p class="text-light no-mgrb max-w-300">
                       The HR Suite with ThinkHR is a powerful tool for companies with employees.  Included in our ThinkHR Suite of tools you will find what all business owners and HR teams love!  Compliance, accessible and reliable information and peace of mind.
                     </p>
                     
                </div>
                <h4 class="head-h4 text-red mgrt-30">Premium Only Plan</h4>
                <div class="included">
                    <p class="text-light no-mgrb max-w-300">Easily get your POP setup in minutes! A premium only plan (POP) will help keep your company compliant with benefit deductions and fair treatment of employee benefit plans.</p>
                </div>
          </div>
           <div class="col-md-4">
               <h4 class="head-h4 text-red mgrt-30">Employee Handbook</h4>
               <div class="included">
                    <p class="text-light no-mgrb max-w-300">Getting an employee handbook in place has never been easier! After just a few minutes of customization your handbook will be ready and compliant. Once the handbook is in place you can easily update with just a few clicks of the button. Use material that has been already approved by attorneys and HR experts.</p>
               </div>
           </div>
           <div class="col-md-2"></div>
           <div class="col-md-6">
               <h4 class="head-h4 text-red mgrt-30">Employee Online Training</h4>
               <div class="included">
                   <p class="text-light no-mgrb max-w-300">Just think how powerful it would be for you to assign training to all current employees along with new hires.  Now that you thought about management training, compliance training, sexual harassment training and other training that you might need - know that we make this available as part of your ThinkHR Suite!</p>
               </div>
               
           </div>
      </div>
        <div class="row">
           <div class="col-md-1"></div>
            <div class="col-md-8">
                <img src="<?php bloginfo('stylesheet_directory'); ?>/assets/images/hand-shake.png" alt="" class="img-fluid img-middle hand-shake-img">
            </div>
        </div>
        
        
        
    </div>
      
  
</section>

