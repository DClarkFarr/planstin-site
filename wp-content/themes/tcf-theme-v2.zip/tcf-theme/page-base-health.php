<?php
/*
 Template Name: Base Health Page
*/
?>


<section class="section-sm bg-gray-light">
    <div class="container text-center">
        <h2 class="m-0 text-secondary f-24 text-uppercase">BASE HEALTH</h2>
    </div>
</section>

<section class="section benefits learn-more bg-white">
    <div class="container">
     
     <p class="text-darkest">Preventive health plans meet the requirements for Minimum Essential Coverage (MEC) as outlined by the Affordable Care Act (ACA).  Groups of fifty (50+) or more employees should also consider a plan that meets the requirements to be a Minimum Value Plan (MVP) to avoid potential penalties for large employers.  Groups of fifty (50+) or more enrolled employees may be eligible for additional discounts.  Ask your Planstin representative for more information.
        </p>
        
    <p class="text-darkest">
    Preventive Base Health plans with a HealthShare plan.  This way you have coverage as seen fit for your base health needs while having a plan in place for catastrophic needs with a HealthShare. 
    </p>
     
      
    <div class="row base-health-two">
        <div class="col-md-6">
            <h4 class="head-h4 text-red">Preventive HSA</h4>
            <div class="hsa-plan">
               
               <ul class="hsa-plans">
                  <li>
                    <h5 class="text-light head-medium mgrt-20">Network</h5>
                        <p class="text-light mgrb-5 max-w-bse-p">Nationwide PPO Network, PHCS. <br>
                        To find a provider call 800-922-4362 or click on the link below.</p>
                        <a href="https://www.multiplan.com/webcenter/portal/ProviderSearch?SiteId=84477" target="_blank"><span class="link-name">Provider Search</span> <i class="far fa-fw mr-3 d-inline-block fa-search" aria-hidden="true"></i>
                        </a>
                  </li>
                  <li>
                      <h5 class="text-light head-medium mgrt-30 no-mgrb">Plan Outline</h5>
                     <a class="download-pln text-light" href="https://drive.google.com/open?id=1RYeRHL_6Kw39wv2VjW2RY6J3GPm-mAsA" target="_blank"><span class="link-name">Download Outline</span> <i class="far fa-fw mr-3 d-inline-block fa-download" aria-hidden="true"></i></a>
                  </li>
                  <li>
                      <h5 class="text-light head-medium mgrt-30 no-mgrb">Telemedicine</h5>
                     <p class="text-light max-w-bse-p">24/7 Access, Unlimited Consultations at $0 copay.  Learn more about <a href="#" target="_blank">TelaDoc.</a></p>
                  </li>
                  <li>
                      <h5 class="text-light head-medium mgrt-30 no-mgrb">Office Visits & Copays</h5>
                       
                        <ul class="hsa-plans1">
                            <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li1"><p class="text-light no-mgrb">TelaDoc</p></li>
                                   <li class="li2"><p class="text-light no-mgrb">$0</p></li>
                               </ul>
                            </li>
                            <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li1"><p class="text-light no-mgrb">Physician Visit</p></li>
                                   <li class="li2"><p class="text-light no-mgrb">$35</p></li>
                                   <li class="li3"><p class="text-light no-mgrb">copay after deductible is met</p></li>
                               </ul>
                            </li>
                            <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li1"><p class="text-light no-mgrb">Specialist Visit</p></li>
                                   <li class="li2"><p class="text-light no-mgrb">$60</p></li>
                                   <li class="li3"><p class="text-light no-mgrb">copay after deductible is met</p></li>
                               </ul>
                            </li>
                            <li>
                                 <ul class="hsa-plans-cost">
                                   <li class="li1"><p class="text-light no-mgrb">Lab (each test)</p></li>
                                   <li class="li2"><p class="text-light no-mgrb">$10 </p></li>
                                   <li class="li3"><p class="text-light no-mgrb">copay after deductible is met</p></li>
                               </ul>
                            </li>
                            
                        </ul>
                  </li>
                  <li>
                     <div class="clearfix"></div>
                      <h5 class="text-light head-medium mgrt-30 no-mgrb">Monthly Rates</h5>
                      <ul class="hsa-plans1">
                            <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li11"><p class="text-light no-mgrb">Employee Only</p></li>
                                   <li class="li2"><p class="text-light no-mgrb">$75</p></li>
                               </ul>
                            </li>
                            <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li11"><p class="text-light no-mgrb">Employee & Spouse</p></li>
                                   <li class="li2"><p class="text-light no-mgrb">$120</p></li>
                               </ul>
                            </li>
                            <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li11"><p class="text-light no-mgrb">Employee & Children</p></li>
                                   <li class="li2"><p class="text-light no-mgrb">$120</p></li>
                               </ul>
                            </li>
                            <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li11"><p class="text-light no-mgrb">Employee & Family </p></li>
                                   <li class="li2"><p class="text-light no-mgrb">$150</p></li>
                               </ul>
                            </li>
                            
                            
                        </ul>
                  </li>
               </ul>
            </div>
        </div>
        
        <div class="col-md-6">
            <h4 class="head-h4 text-red mgrt-mobile">Preventive Advanced</h4>
            <div class="hsa-plan">
               
               <ul class="hsa-plans">
                  <li>
                    <h5 class="text-light head-medium mgrt-20">Network</h5>
                        <p class="text-light mgrb-5 max-w-bse-p">Nationwide PPO Network, PHCS. <br>
                        To find a provider call 800-922-4362 or click on the link below.</p>
                       <a href="https://www.multiplan.com/webcenter/portal/ProviderSearch?SiteId=84477" target="_blank"><span class="link-name">Provider Search</span> <i class="far fa-fw mr-3 d-inline-block fa-search" aria-hidden="true"></i>
                        </a>
                  </li>
                  <li>
                      <h5 class="text-light head-medium mgrt-30 no-mgrb">Plan Outline</h5>
                     <a class="download-pln text-light" href="https://drive.google.com/open?id=1RYeRHL_6Kw39wv2VjW2RY6J3GPm-mAsA" target="_blank"><span class="link-name">Download Outline</span> <i class="far fa-fw mr-3 d-inline-block fa-download" aria-hidden="true"></i></a>
                  </li>
                  <li>
                      <h5 class="text-light head-medium mgrt-30 no-mgrb">Telemedicine</h5>
                     <p class="text-light max-w-bse-p">24/7 Access, Unlimited Consultations at $0 copay.  Learn more about <a href="#" target="_blank">TelaDoc.</a></p>
                  </li>
                  <li>
                      <h5 class="text-light head-medium mgrt-30 no-mgrb">Office Visits & Copays</h5>
                       
                        <ul class="hsa-plans1">
                            <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li1"><p class="text-light no-mgrb">TelaDoc</p></li>
                                   <li class="li2"><p class="text-light no-mgrb">$0</p></li>
                               </ul>
                            </li>
                            <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li1"><p class="text-light no-mgrb">Physician Visit</p></li>
                                   <li class="li2"><p class="text-light no-mgrb">$35</p></li>
                                   <li class="li3"><p class="text-light no-mgrb">copay after deductible is met</p></li>
                               </ul>
                            </li>
                            <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li1"><p class="text-light no-mgrb">Specialist Visit</p></li>
                                   <li class="li2"><p class="text-light no-mgrb">$60</p></li>
                                   <li class="li3"><p class="text-light no-mgrb">copay after deductible is met</p></li>
                               </ul>
                            </li>
                            <li>
                                 <ul class="hsa-plans-cost">
                                   <li class="li1"><p class="text-light no-mgrb">Lab (each test)</p></li>
                                   <li class="li2"><p class="text-light no-mgrb">$10 </p></li>
                                   <li class="li3"><p class="text-light no-mgrb">copay after deductible is met</p></li>
                               </ul>
                            </li>
                            
                        </ul>
                  </li>
                  <li>
                     <div class="clearfix"></div>
                      <h5 class="text-light head-medium mgrt-30 no-mgrb">Monthly Rates</h5>
                      <ul class="hsa-plans1">
                            <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li11"><p class="text-light no-mgrb">Employee Only</p></li>
                                   <li class="li2"><p class="text-light no-mgrb">$75</p></li>
                               </ul>
                            </li>
                            <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li11"><p class="text-light no-mgrb">Employee & Spouse</p></li>
                                   <li class="li2"><p class="text-light no-mgrb">$120</p></li>
                               </ul>
                            </li>
                            <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li11"><p class="text-light no-mgrb">Employee & Children</p></li>
                                   <li class="li2"><p class="text-light no-mgrb">$120</p></li>
                               </ul>
                            </li>
                            <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li11"><p class="text-light no-mgrb">Employee & Family </p></li>
                                   <li class="li2"><p class="text-light no-mgrb">$150</p></li>
                               </ul>
                            </li>
                            
                            
                        </ul>
                  </li>
               </ul>
            </div>
        </div>
        
        
        <div class="bar">
            <img class="img-fluid img-middle doctor-img" src="<?php bloginfo('stylesheet_directory'); ?>/assets/images/doctor.png" alt="">
        </div>
        
        
    </div>
      
      
      
      
    </div>
</section>

