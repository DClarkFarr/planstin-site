<?php
/*
 Template Name: Dental Plan
*/
?>


<section class="section-sm bg-gray-light">
    <div class="container text-center">
        <h2 class="m-0 text-secondary f-24 text-uppercase">DENTAL PLAN</h2>
    </div>
</section>

<section class="section benefits learn-more bg-white">
    <div class="container">
     
     <p class="text-darkest">One great way to keep healthy is to keep your mouth healthy. The preventive health care of a dental plan can make all the difference now and years to come. The Copay Plan and PPO Plans are competitive plans that offer great coverage and at a great rate.
        </p>
        
      
    <div class="row base-health-two">
        <div class="col-md-6">
            <h4 class="head-h4 text-red">Copay Plan</h4>
            <div class="hsa-plan-no">
               
               <ul class="hsa-plans">
                  <li>
                    <h5 class="text-light head-medium mgrt-20">Network</h5>
                        <p class="text-light mgrb-5 max-w-413">Plan provides access to the Connection Dental® national PPO network of dental providers. You can search for a provider at <a href="http://www.ppousa.com" target="_blank">www.ppousa.com</a> or call 800-513-7177.
                      </p>
                  </li>
                  <li>
                      <h5 class="text-light head-medium mgrt-30 no-mgrb">Plan Outline</h5>
                    <a class="download-pln text-light" href="https://drive.google.com/open?id=1RYeRHL_6Kw39wv2VjW2RY6J3GPm-mAsA" target="_blank"><span class="link-name">Download Outline</span> <i class="far fa-fw mr-3 d-inline-block fa-download" aria-hidden="true"></i></a>
                  </li>
                  <li>
                    <h5 class="text-light head-medium mgrt-20">Copay</h5>
                        <p class="text-light mgrb-5 max-w-413">Plan pays 100% of preventive services including cleanings. Copay schedule for basic and major services. See <a href="#">schedule of copays</a> for more details. No annual limits or deductibles in this plan.
                      </p>
                  </li>
                  <li>
                    <h5 class="text-light head-medium mgrt-20">Added Vision</h5>
                        <p class="text-light mgrb-5 max-w-413">Vision discount card with Connection Vision® included. Find a participating provider by visiting <a href="http://www.EyeMedVisionCare.com" target="_blank">www.EyeMedVisionCare.com</a> or call 866-801-1479.
                      </p>
                  </li>
                  <li>
                     <div class="clearfix"></div>
                      <h5 class="text-light head-medium mgrt-30 no-mgrb">Monthly Rates</h5>
                      <ul class="hsa-plans1">
                            <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li11"><p class="text-light no-mgrb">Employee Only</p></li>
                                   <li class="li2"><p class="text-light no-mgrb">$75</p></li>
                               </ul>
                            </li>
                            <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li11"><p class="text-light no-mgrb">Employee & Spouse</p></li>
                                   <li class="li2"><p class="text-light no-mgrb">$120</p></li>
                               </ul>
                            </li>
                            <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li11"><p class="text-light no-mgrb">Employee & Children</p></li>
                                   <li class="li2"><p class="text-light no-mgrb">$120</p></li>
                               </ul>
                            </li>
                            <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li11"><p class="text-light no-mgrb">Employee & Family </p></li>
                                   <li class="li2"><p class="text-light no-mgrb">$150</p></li>
                               </ul>
                            </li>
                            
                            
                        </ul>
                  </li>
               </ul>
            </div>
        </div>

        <div class="col-md-6">
            <h4 class="head-h4 text-red mgrt-mobile">Plus Plan</h4>
            <div class="hsa-plan-no">
               
               <ul class="hsa-plans">
                  <li>
                    <h5 class="text-light head-medium mgrt-20">Network</h5>
                        <p class="text-light mgrb-5 max-w-413">Plan provides access to the Connection Dental® national PPO network of dental providers. You can search for a provider at <a href="http://www.ppousa.com" target="_blank">www.ppousa.com</a> or call 800-513-7177.
                      </p>
                  </li>
                  <li>
                      <h5 class="text-light head-medium mgrt-30 no-mgrb">Plan Outline</h5>
                    <a class="download-pln text-light" href="https://drive.google.com/open?id=1RYeRHL_6Kw39wv2VjW2RY6J3GPm-mAsA" target="_blank"><span class="link-name">Download Outline</span> <i class="far fa-fw mr-3 d-inline-block fa-download" aria-hidden="true"></i></a>
                  </li>
                  <li>
                    <div class="clearfix"></div>
                      <h5 class="text-light head-medium mgrt-30 no-mgrb">Coverage Tiers</h5>
                      <ul class="hsa-plans1">
                            <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li112"><p class="text-light no-mgrb">Preventive</p></li>
                                   <li class="li22"><p class="text-light no-mgrb">Tier 1</p></li>
                                   <li><p class="text-light no-mgrb">100%</p></li>
                               </ul>
                            </li>
                            <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li112"><p class="text-light no-mgrb">Basic Services</p></li>
                                   <li class="li22"><p class="text-light no-mgrb">Tier 2</p></li>
                                   <li><p class="text-light no-mgrb">80%</p></li>
                               </ul>
                            </li>
                             <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li112"><p class="text-light no-mgrb">Major Services</p></li>
                                   <li class="li22"><p class="text-light no-mgrb">Tier 3</p></li>
                                   <li><p class="text-light no-mgrb">50%</p></li>
                               </ul>
                            </li>
                            
                        </ul>
                  </li>
                  <li>
                   <div class="clearfix"></div>
                    <h5 class="text-light head-medium mgrt-20">Deductible</h5>
                        <p class="text-light mgrb-5 max-w-413">Calendar year deductible of $50 per person, $150 for the family.  Deductible applies to Tier 2 and 3.  Deductible does not apply to Tier 1 services.
                      </p>
                  </li>
                  <li>
                   <div class="clearfix"></div>
                    <h5 class="text-light head-medium mgrt-20">Annual Limit</h5>
                        <p class="text-light mgrb-5 max-w-413">Plan will pay up to $1,500 per year, per member.
                      </p>
                  </li>
                  <li>
                   <div class="clearfix"></div>
                    <h5 class="text-light head-medium mgrt-20">Added Vision</h5>
                        <p class="text-light mgrb-5 max-w-413">Vision discount card with Connection Vision® included. Find a participating provider by visiting <a href="http://www.EyeMedVisionCare.com" target="_blank">www.EyeMedVisionCare.com</a> or call 866-801-1479.
                      </p>
                  </li>
                  
                  <li>
                     <div class="clearfix"></div>
                      <h5 class="text-light head-medium mgrt-30 no-mgrb">Monthly Rates</h5>
                      <ul class="hsa-plans1">
                            <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li11"><p class="text-light no-mgrb">Employee Only</p></li>
                                   <li class="li2"><p class="text-light no-mgrb">$75</p></li>
                               </ul>
                            </li>
                            <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li11"><p class="text-light no-mgrb">Employee & Spouse</p></li>
                                   <li class="li2"><p class="text-light no-mgrb">$120</p></li>
                               </ul>
                            </li>
                            <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li11"><p class="text-light no-mgrb">Employee & Children</p></li>
                                   <li class="li2"><p class="text-light no-mgrb">$120</p></li>
                               </ul>
                            </li>
                            <li>
                               <ul class="hsa-plans-cost">
                                   <li class="li11"><p class="text-light no-mgrb">Employee & Family </p></li>
                                   <li class="li2"><p class="text-light no-mgrb">$150</p></li>
                               </ul>
                            </li>
                            
                            
                        </ul>
                  </li>
               </ul>
            </div>
        </div>

        
        
        <div class="bar bar2">
            <img class="img-fluid teeth-img" src="<?php bloginfo('stylesheet_directory'); ?>/assets/images/teeth.png" alt="">
        </div>
        
        
    </div>
      
      
      
      
    </div>
</section>

