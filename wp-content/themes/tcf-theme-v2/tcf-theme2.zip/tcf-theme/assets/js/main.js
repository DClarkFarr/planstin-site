$(function(){
  console.log('ready');

  $('.testimonials .owl-carousel').owlCarousel({
      loop:true,
      nav:false,
      items: 1,
      dots: true,
  });
});

    $(document).ready(function(){
      $('input').iCheck({
        checkboxClass: 'icheckbox_flat-red',
        radioClass: 'iradio_flat-red'
      });
    });