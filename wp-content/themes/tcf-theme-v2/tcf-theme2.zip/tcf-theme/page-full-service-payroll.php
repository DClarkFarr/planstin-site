<?php
/*
 Template Name: Full service payroll
*/
?>


<section class="section-sm bg-gray-light">
    <div class="container text-center">
        <h2 class="m-0 text-secondary f-24 text-uppercase">FULL SERVICE PAYROLL</h2>
    </div>
</section>

<section class="section benefits learn-more bg-white">
    <div class="container">
     
     <p class="text-darkest txt-center">Payroll made easy with a dedicated payroll specialist, all taxes and forms processed, direct deposit payroll, HR Suite and more.  Our services can make payroll deductions and workers comp reporting a breeze so that you can focus on your business.
        </p>
     
      
    <div class="row base-health-two">
       <div class="col-md-1"></div>
        <div class="col-md-4">
                <h4 class="head-h4 text-red">What's included?</h4>
                <div class="included">
                     <p class="text-light no-mgrb">

                        Local Payroll Forms and Taxes <br>
                        Federal Payroll Forms and Taxes	<br>
                        Annual W2's	<br>
                        Annual 1099's	<br>
                        Pay Employees and/or Contractors<br>	
                        Employer Online Access	<br>
                        Employee Paystub Access	<br>
                        Benefit Integration	<br>
                        Vacation/Sick Time Tracking	<br>
                        Direct Deposit<br>	
                        Dedicated Payroll Specialist<br>	
                        Company Checks<br>	
                        Delivered Checks<br>	
                        Tip Processing	<br>
                        Background Checks	<br>
                        

                     </p>
                     <h5 class="head-medium text-light head-mediu2">* ThinkHR Suite</h5>
                     <h5 class="head-medium text-light mgrt-50">Time Keeping</h5>
                     <p class="text-light">Add $2 per employee</p>
                     <h5 class="head-medium text-light mgrt-20">Base Plan</h5>
                     <p class="text-light">$100.00 Monthly</p>
                     <h5 class="head-medium text-light mgrt-20">Per Employee/Contractor</h5>
                     <p class="text-light">$2.00 monthly</p>
                     
                </div>
            </div>
            <div class="col-md-7">
                <h4 class="head-h4 text-red mgrt-mobile">What's ThinkHR Suite?</h4>
                <div class="included">
                    <P class="text-light max-w-300">The HR Suite with ThinkHR is a powerful tool for companies with employees.  Included in our ThinkHR Suite of tools you will find what all business owners and HR teams love!  Compliance, accessible and reliable information and peace of mind.</P>
                </div>
                <img class="img-fluid img-middle lady-img" src="<?php bloginfo('stylesheet_directory'); ?>/assets/images/lady.png" alt="">
            </div>
        </div>
        
        
        
        
    </div>
      
  
</section>

